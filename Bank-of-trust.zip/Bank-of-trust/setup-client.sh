#!/bin/bash
cd client
npm install
echo "Dependencies installed"