
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Check, CreditCard, Shield, Zap, ChevronRight } from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-bank-blue to-bank-teal pt-20 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div className="space-y-6">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
                Banking Reimagined For The Digital Age
              </h1>
              <p className="text-xl text-white/80">
                Experience seamless, secure, and smart banking with Bank of Trust. 
                Your finances, simplified.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 pt-4">
                <Button
                  asChild
                  className="bg-white text-bank-blue hover:bg-white/90"
                  size="lg"
                >
                  <Link to="/dashboard">Get Started</Link>
                </Button>
                <Button
                  asChild
                  variant="outline"
                  className="border-white text-white hover:bg-white/10"
                  size="lg"
                >
                  <Link to="/dashboard">View Demo</Link>
                </Button>
              </div>
            </div>
            <div className="relative hidden md:block">
              <div className="relative">
                <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 shadow-xl animate-float">
                  <div className="w-full h-56 bg-gradient-to-br from-blue-700 to-cyan-400 rounded-xl p-4 relative overflow-hidden">
                    <div className="flex flex-col h-full justify-between">
                      <div className="flex justify-between">
                        <div className="text-white font-semibold">Bank of Trust</div>
                        <div className="h-8 w-12 bg-white/20 backdrop-blur rounded"></div>
                      </div>
                      <div>
                        <div className="mt-4">
                          <div className="w-12 h-6 bg-white/20 backdrop-blur rounded"></div>
                        </div>
                        <div className="text-white text-xl font-bold mt-1">**** **** **** 4589</div>
                      </div>
                      <div className="flex justify-between items-end">
                        <div>
                          <div className="text-white/80 text-xs">CARD HOLDER</div>
                          <div className="text-white font-medium">ALEX JOHNSON</div>
                        </div>
                        <div>
                          <div className="text-white/80 text-xs">EXPIRES</div>
                          <div className="text-white font-medium">05/28</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-4 space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Balance</span>
                      <span className="text-white font-semibold">$5,842.50</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Card Type</span>
                      <span className="text-white font-semibold">Visa Platinum</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Status</span>
                      <span className="bg-green-500/20 text-green-400 px-2 py-1 rounded-full text-xs">Active</span>
                    </div>
                  </div>
                </div>

                <div className="absolute -bottom-10 -right-10 bg-white/10 backdrop-blur-lg rounded-2xl p-4 border border-white/20 shadow-xl animate-float" style={{ animationDelay: "0.5s" }}>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                      <Check className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                      <div className="text-white font-semibold">Transaction Complete</div>
                      <div className="text-white/70 text-sm">Coffee Shop • $4.50</div>
                    </div>
                  </div>
                </div>

                <div className="absolute -top-10 -left-10 bg-white/10 backdrop-blur-lg rounded-2xl p-4 border border-white/20 shadow-xl animate-float" style={{ animationDelay: "1s" }}>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <CreditCard className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <div className="text-white font-semibold">New Card Ready</div>
                      <div className="text-white/70 text-sm">Activate Now</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Wave separator */}
        <div className="relative h-20">
          <svg className="absolute bottom-0 w-full h-20" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
            <path fill="#ffffff" fillOpacity="1" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,117.3C672,107,768,117,864,138.7C960,160,1056,192,1152,186.7C1248,181,1344,139,1392,117.3L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
          </svg>
        </div>
      </section>
      
      {/* Features Section */}
      <section id="features" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 gradient-text">Powerful Features</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Everything you need in a modern banking experience, 
              designed for simplicity and security.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gray-50 rounded-2xl p-6 transition-all hover:shadow-lg">
              <div className="w-12 h-12 bg-bank-accent/10 rounded-full flex items-center justify-center mb-4">
                <Shield className="h-6 w-6 text-bank-accent" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Advanced Security</h3>
              <p className="text-gray-600">
                Multi-layered encryption and biometric authentication to keep your finances secure.
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-2xl p-6 transition-all hover:shadow-lg">
              <div className="w-12 h-12 bg-bank-success/10 rounded-full flex items-center justify-center mb-4">
                <Zap className="h-6 w-6 text-bank-success" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Instant Transfers</h3>
              <p className="text-gray-600">
                Send money to anyone, anywhere in the world with real-time processing.
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-2xl p-6 transition-all hover:shadow-lg">
              <div className="w-12 h-12 bg-bank-blue/10 rounded-full flex items-center justify-center mb-4">
                <CreditCard className="h-6 w-6 text-bank-blue" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Smart Cards</h3>
              <p className="text-gray-600">
                Virtual and physical cards with dynamic limits and instant notifications.
              </p>
            </div>
          </div>
          
          <div className="mt-12 text-center">
            <Button asChild variant="outline" size="lg">
              <Link to="/dashboard" className="flex items-center">
                Explore All Features <ChevronRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="bg-gradient-to-br from-bank-blue to-bank-teal py-16 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Start Banking Smarter?</h2>
            <p className="text-xl text-white/80 max-w-2xl mx-auto mb-8">
              Join thousands of customers who trust us with their financial journey.
              Get started in minutes.
            </p>
            <Button
              asChild
              className="bg-white text-bank-blue hover:bg-white/90"
              size="lg"
            >
              <Link to="/dashboard">Open Your Account Now</Link>
            </Button>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default Index;
